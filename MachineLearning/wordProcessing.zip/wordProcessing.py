import re, string, random, glob, operator, heapq, language_check
from collections import defaultdict
from math import log10
from random import randint
tool = language_check.LanguageTool('en-US')
from urllib.request import urlopen
import urllib.parse
import json as simplejson
import random
import time

def memo(f):
    "Memoize function f."
    table = {}
    def fmemo(*args):
        if args not in table:
            table[args] = f(*args)
        return table[args]
    fmemo.memo = table
    return fmemo

def Pwords(words):
    "The Naive Bayes probability of a sequence of words."
    return product(Pw(w) for w in words)

class Pdist(dict):
    "A probability distribution estimated from counts in datafile."
    def __init__(self, data=[], N=None, missingfn=None):
        for key,count in data:
            self[key] = self.get(key, 0) + int(count)
        self.N = float(N or sum(self.itervalues()))
        self.missingfn = missingfn or (lambda k, N: 1./N)
    def __call__(self, key):
        if key in self: return self[key]/self.N  
        else: return self.missingfn(key, self.N)

def datafile(name, sep='\t'):
    "Read key,value pairs from file."
    for line in open(name):
        yield line.split(sep)

def avoid_long_words(key, N):
    "Estimate the probability of an unknown word."
    return 10./(N * 10**len(key))

N = 1024908267229 ## Number of tokens

PAD  = Pdist(datafile('PAD.txt'), 235)
Pw  = Pdist(datafile('count_1w.txt'), N, avoid_long_words)
Pw2  = Pdist(datafile('wl1.txt'), 3845, avoid_long_words)

def cPw(word, prev):
    "Conditional probability of word, given previous word."
    try:
        return P2w[prev + ' ' + word]/float(Pw[prev])
    except KeyError:
        return Pw(word)

def cPw2(word, prev):
    "Conditional probability of word, given previous word."
    try:
        return P2w2[prev + ' ' + word]/float(Pw2[prev])
    except KeyError:
        return Pw2(word)
    
P2w = Pdist(datafile('count_2w.txt'), N)
P2w2 = Pdist(datafile('wl.txt'), 8504)

@memo
def predict(text, prev='<S>'):
    "Return a list of words that is the best segmentation of text."
    candidates = []
    best = ""
    word = ""
    copy = text.split()
    cText = text
    difference = 0
    count = 0
    found = False
    last = 0
    array = []
    matches = tool.check(text)
    if (len(matches)>= 1):
        for i in range(len(matches)):
            index = matches[i].fromx
            suggestions = matches[i].replacements
            found = False
            word = ""
            sug = suggestions[0]
            for x in range(len(copy)):
                if(copy[x] == text[index:index+len(copy[x])]):
                    last = x-1
                    break
            if(len(sug.split()) == 2):
                wordList = suggestWord(sug)
                for k in wordList:
                    u = k.split()
                    array.append(cPw(u[1], u[0]))
            elif(len(sug.split()) == 1):
                wordList = suggestWord(sug)
                if(last < 0):
                    v = sug
                else:
                    v = copy[last]
                for k in wordList:
                    array.append(cPw(k, v))
            numm = -10000
            indexx = 0
            for x in range(len(wordList)):
                if(array[x] > numm):
                    numm = array[x]
                    indexx = x     
            word = wordList[indexx]
            if(len(sug.split()) == 1):
                wordList = suggestWord(word, True)
                array = []
                if(last < 0):
                    v = sug
                else:
                    v = copy[last]
                for k in range(len(wordList)):
                    if(k == 0):
                        array.append(ggl(v+" "+wordList[k], False))
                    else:
                        array.append(ggl(v+" "+wordList[k]))
                numm = -10000
                indexx = 0
                for x in range(len(wordList)-1):
                    if(array[x] > numm):
                        numm = array[x]
                        indexx = x     
                word = wordList[indexx]  
            if(word != "" ):
                length = 0
                if(len(sug.split()) == 2):
                    if(count == 0):
                        cText = text[:index] + word.lower() + text[index+len(sug):]
                    else:
                        cText = cText[:index+difference] + word.lower() + cText[index+len(sug)+difference:]
                    count += 1
                else:
                    for x in copy:
                        if(x.lower() == text[index:index+len(x)].lower()):
                            length = len(x)
                            break
                    if(length > 0):
                        #found the word we want to replace
                        if(count == 0):
                            cText = text[:index] + word.lower() + text[index+length:]
                        else:
                            cText = cText[:index+difference] + word.lower() + cText[index+length+difference:]
                        if(len(word) != length):
                            difference += abs(len(word) - length)
                        count += 1
                    else:
                        print("didn't find the word")
        return cText
    print("No errors found")

def suggestWord(text, pad=False):
    ret = [text]
    a = text.split()
    if(len(a) == 2):
        for k in P2w2:
            j = k.split()
            if(a[0].lower()[:1]  == j[0].lower()[:1] and a[1].lower()[:1] == j[1].lower()[:1]):
                ret.append(k)
                if(len(ret) >= 10):
                    return ret
    elif(len(a) == 1):
        if(pad == True):
            for k in PAD:
                if(a[0].lower()[:1]  == k.lower()[:1]):
                    ret.append(k)
                    if(len(ret) >= 5):
                        return ret
        else:
            for k in Pw2:
                if(a[0].lower()[:1]  == k.lower()[:1]):
                    ret.append(k)
                    if(len(ret) >= 10):
                        return ret
    else:
        return text

def ggl(text, lax=True):
    n = 0
    if(lax):
        query = urllib.parse.urlencode({'q' : text})
    else:
        query = urllib.parse.urlencode({'q' : '"'+text+'"'})
    url = 'http://ajax.googleapis.com/ajax/services/search/web?v=1.0&%s'%(query)
    error = True
    while(error == True):
        search_results = urlopen(url)
        lol = search_results.read().decode('utf-8')
        json = simplejson.loads(lol)
        if(json['responseStatus'] != 200):
            print("error, need to wait before querying again!")
            error = True
            if(n > 2):
                return 0
            time.sleep((2 ** n) + random.random())
            n += 1
        else:
            error = False
    if(json['responseData']['results']):
        return int(json['responseData']['cursor']['estimatedResultCount'])
    else:
        return 0
